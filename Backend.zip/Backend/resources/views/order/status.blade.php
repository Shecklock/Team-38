<h1>order id: {{ $order->ID }}</h1>
<h1>Order Status</h1>
<p>Your order status is: {{ $order->status }}</p>
