<?php $__env->startSection('content'); ?>

    <div class="pull-left">
        <h2>Product Management System</h2>
    </div>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <a class="btn btn-success" href="<?php echo e(route('products.create')); ?>">Create new product</a>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>ProductID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Category</th>
                <th>Image</th>
                <th>Price</th>
                <th>Action</th>
            </tr>
        </thead>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($product->ProductName); ?></td>
                <td><?php echo e($product->Description); ?></td>
                <td><?php echo e($product->category->CategoryName ?? 'Uncategorized'); ?></td>
                <td>
                    <?php if($product->image): ?>
                        <img src="<?php echo e(asset('admin/images/' . $product->image)); ?>" width="200px" height="200px" alt="Product Image">
                    <?php else: ?>
                        No Image
                    <?php endif; ?>
                </td>    
                <td><?php echo e($product->Price); ?></td>
                <td>
                    <form onsubmit="return confirm('Are you sure you want to delete?')" action="<?php echo e(route('products.destroy', $product->ProductID)); ?>" method="POST">
                        <a class="btn btn-info" href="<?php echo e(route('products.show', $product->ProductID)); ?>">Show</a>
                        <a class="btn btn-primary" href="<?php echo e(route('products.edit', $product->ProductID)); ?>">Edit</a>

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP\htdocs\Team 38\Team-38\Backend\resources\views/admin/products/index.blade.php ENDPATH**/ ?>