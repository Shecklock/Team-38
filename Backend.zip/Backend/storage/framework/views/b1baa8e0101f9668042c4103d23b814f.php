<html lang = "en">
   <head>
        <title>404 Page Not Found</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/404.css')); ?>">
        <script src="https://kit.fontawesome.com/155df07167.js" crossorigin="anonymous"></script>
   </head>
   <body>
    <header>
        <div id="header">
            <div class="container1">
                <nav>
                    <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('assets/sources/logo2.png')); ?>" class="logo"></a>
                    
                        <ul>
                            <li>    <form action="<?php echo e(url('/search')); ?>" method="GET" role="search">
                                    <div class="input-group">                                  
                                        <input type="search" name="search" placeholder=" Products...">
                                        <button class="btn bg-white" type="submit">
                                            <i>search<i>
                                    </div>
                                </form>
                            </li>
                            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li><a href="<?php echo e(route('showproducts')); ?>">Products</a></li>
                            <li class="active"><a href="contact-us">Contact Us</a></li>
                            <li><a href="<?php echo e(route('about_us')); ?>">About Us</a></li>
                        
                            <?php if(auth()->guard()->guest()): ?>
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                            <?php if(Route::has('register')): ?>
                                <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                            <?php endif; ?>
                            <?php else: ?>
                            <li>
                                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                    <i class="mdi mdi-logout text-primary"></i> Logout
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                            <li><a href="a">Account</a></li>
                            <?php endif; ?>
                        
                        <li><a href="<?php echo e(route('basket')); ?>"><i class="fa-solid fa-basket-shopping"></i></a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>
      <div clas="content">
         <h3>404 error. The page you are looking for does not exist, or is temporarily unavailable.</h3>
      </div>
      <footer>
         <p>
            <a href="../../assets/contact_us.html">Contact us</a><br>
            Telephone: +44 123435390 <br>
            Email: sportifypromax@gmail.com
         </p>
         <p>
            <a href="../../assets/about_us.html">About us </a><br>
            Address: Aston St, Birmingham B4 7ET
         </p>
         <p>
            <a href="../../assets/faqs.html">FAQs</a><br>
            <a href="https://www.instagram.com/">Instagram</a><br>
            <a href="https://en-gb.facebook.com/">Facebook</a><br>
            <a href="https://twitter.com/login">X</a>
         </p>
      </footer>
   </body>
</html<?php /**PATH C:\XAMPP\htdocs\Team 38\Team-38\Backend\resources\views//errors/404.blade.php ENDPATH**/ ?>